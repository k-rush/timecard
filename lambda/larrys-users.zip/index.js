'use sctrict';
var crypto = require('crypto');
var async = require('async');
var AWS = require('aws-sdk');
var validator = require('validator');
const doc = require('dynamodb-doc');
const dynamo = new doc.DynamoDB();

AWS.config.update({region: 'us-west-2'});

/** Register, update, get users */
exports.handler = function(event, context, callback) {
	const done = (err, res) => callback(null, {
		statusCode: err ? (err.code ? err.code : '400') : '200',
		body: err ? err.message : JSON.stringify(res),
		headers: {
			'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*'
		}
	});

	switch (event.httpMethod) {
		case 'POST':
			//Register new user

			//Waterfall
			// set configuration

			async.waterfall([
				async.apply(setConfig, event)
			]);
			break;
		case 'GET':
			//Get user(s)

			// If a username is provided, will get that particular user,  otherwise gets all users

			//Waterfall
			// set configuration

			async.waterfall([
				async.apply(setConfig, event)

			]);
			break;
		case 'UPDATE':
			//Update user

			//Waterfall
			// set configuration

			async.waterfall([
				async.apply(setConfig, event)
			]);
			break;
		case 'DELETE':
			//Delete user

			//Waterfall
			// set configuration

			async.waterfall([
				async.apply(setConfig, event)
			]);
			break;
		default:
			done({code:'400', message:`Unsupported HTTP Method "${event.httpMethod}"`});
	}
};

function setConfig(event, callback) {
	var queryParams = {
		Key: {
			"stage": event.requestContext.stage
		},
		TableName: "larrys-config"
	};

	dynamo.getItem(queryParams, function(err, data) {
		if(err || data.Item.length === 0) {
			console.log(err);
			callback({code:'500', message:'Internal server error'}, data);
		}
		else {
			console.log("Configutaion Item: " + JSON.stringify(data.Item));
			//callback with data.Item as configuration item.
		}
	});


}


/** Validates all of the user registration fields */
function validateFields(body, configuration, callback) {
    if(isString(body.username) && isString(body.firstname) && isString(body.lastname) && validator.isEmail(body.email) && validatePassword(body.password))
        callback(null, body, configuration);
    else callback({message: 'Invalid registration inputs', code:'400'});                         
}

/** Sanitize inputs for html */
function sanitizeFields(body, configuration, callback) {
    body.username = validator.escape(validator.trim(body.username));
    body.firstname = validator.escape(body.firstname);
    body.lastname = validator.escape(body.lastname);
    body.email = validator.normalizeEmail(validator.escape(body.email));
    callback(null, body, configuration);
}


/** Validates password */
function validatePassword(password) {
    return (isString(password) && password.length > 5)
}

/** Tests typeof data is string */
function isString(data) {
    return (typeof data === 'string');
}

function queryUserDB(body, configuration, callback) {
    var queryParams = {
        TableName : configuration['user-table'],
        KeyConditionExpression: "#s = :user",
        ExpressionAttributeNames:{
            "#s": "SearchField"
        },
        ExpressionAttributeValues: {
            ":user":body.username.toLowerCase()
        }
    };

    //Need query here, because we do not have UserID... How can we make this faster?
    dynamo.query(queryParams, function(err,data) {
        if(err) {
            console.log(err);
            callback(err,data);
        }

        else {
            console.log("QUERY RESULT:" + JSON.stringify(data.Items));
            if(data.Items.length === 0) {
                callback(null, body, configuration);

            }
            else {
                callback({message: 'Username already exists'});
            }
        }
    });
}